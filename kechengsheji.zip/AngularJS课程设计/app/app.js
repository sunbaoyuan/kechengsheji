// Èë¿ÚÎÄ¼þ
var app=angular.module('myapp',[]);
	app.controller('mainctrl',function($scope){
		$scope.user=;
	})